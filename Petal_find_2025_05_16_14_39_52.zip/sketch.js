let gameState = "menu";
let player;
let obstacles = [];
let obstacleSpeed = 4;
let backgroundColor;
let playerEmoji = "🏃";
let obstacleEmoji = "🍅";

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(32);
  player = new Player();
}

function draw() {
  if (gameState === "menu") {
    showMenu();
  } else if (gameState === "parque" || gameState === "cozinha") {
    runGame();
  }
}

function showMenu() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  fill(0);
  text("Escolha o cenário:", width / 2, height / 2 - 40);
  text("Pressione P para Parque 🌳", width / 2, height / 2);
  text("Pressione C para Cozinha 🍳", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (gameState === "menu") {
    if (key === "p" || key === "P") {
      gameState = "parque";
      backgroundColor = color(100, 200, 100);
      playerEmoji = "🏃";
      obstacleEmoji = "🍅";
      resetGame();
    } else if (key === "c" || key === "C") {
      gameState = "cozinha";
      backgroundColor = color(220, 180, 150);
      playerEmoji = "👨‍🍳";
      obstacleEmoji = "🍅";
      resetGame();
    }
  }
}

function runGame() {
  background(backgroundColor);
  player.update();
  player.show();

  if (frameCount % 60 === 0) {
    obstacles.push(new Obstacle());
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    if (obstacles[i].hits(player)) {
      gameState = "menu";
      break;
    }

    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
    }
  }
}

function resetGame() {
  obstacles = [];
  player = new Player();
}

// Classe do jogador
class Player {
  constructor() {
    this.x = 50;
    this.y = height / 2;
    this.size = 32;
  }

  update() {
    if (keyIsDown(UP_ARROW)) this.y -= 5;
    if (keyIsDown(DOWN_ARROW)) this.y += 5;
    this.y = constrain(this.y, 0, height - this.size);
  }

  show() {
    textSize(this.size);
    text(playerEmoji, this.x, this.y);
  }

  getBounds() {
    return { 
      x: this.x - 16, 
      y: this.y - 16, 
      w: 32, 
      h: 32 
    };
  }
}

// Classe do obstáculo
class Obstacle {
  constructor() {
    this.x = width;
    this.y = random(height - 32);
    this.size = 32;
  }

  update() {
    this.x -= obstacleSpeed;
  }

  show() {
    textSize(this.size);
    text(obstacleEmoji, this.x, this.y);
  }

  hits(player) {
    const p = player.getBounds();
    const o = { 
      x: this.x - 16, 
      y: this.y - 16, 
      w: 32, 
      h: 32 
    };
    
    // Detecção de colisão AABB (Axis-Aligned Bounding Box)
    return (
      p.x < o.x + o.w &&
      p.x + p.w > o.x &&
      p.y < o.y + o.h &&
      p.y + p.h > o.y
    );
  }

  offscreen() {
    return this.x + this.size < 0;
  }
}